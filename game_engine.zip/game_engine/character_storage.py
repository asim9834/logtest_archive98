import json
import os

CHARACTER_FILE_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "custom_characters.json")

def save_characters_to_file(characters):
    os.makedirs(os.path.dirname(CHARACTER_FILE_PATH), exist_ok=True)
    with open(CHARACTER_FILE_PATH, "w", encoding="utf-8") as file:
        json.dump(characters, file, ensure_ascii=False, indent=4)

def load_custom_characters():
    if not os.path.exists(CHARACTER_FILE_PATH):
        return []
    with open(CHARACTER_FILE_PATH, "r", encoding="utf-8") as file:
        return json.load(file)